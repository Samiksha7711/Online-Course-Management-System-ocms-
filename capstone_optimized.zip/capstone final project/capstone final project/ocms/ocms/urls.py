from django.contrib import admin
from django.urls import path, include
from dashboard.views import dashboard_view
from .views import home_view, courses_view  # 👈 added

urlpatterns = [
    path('admin/', admin.site.urls),

    # frontend
    path('', home_view),
    path('courses/', courses_view, name='courses'),

    # api
    path('api/', include('accounts.urls')),
    path('api/', include('courses.urls')),
    path('api/', include('enrollments.urls')),
    path('api/', include('reviews.urls')),
]