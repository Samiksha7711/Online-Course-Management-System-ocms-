const BASE_URL = "http://127.0.0.1:8000/api/";

// ================= FETCH COURSES =================
async function loadCourses() {
    try {
        let res = await fetch(BASE_URL + "courses/");
        let data = await res.json();

        let container = document.getElementById("courseList");
        container.innerHTML = "";

        // Convert API response to array safely
        const list = data.courses || data;

        if (!Array.isArray(list)) {
            console.error("Courses API did not return an array:", list);
            container.innerHTML = "<p>No courses found.</p>";
            return;
        }

        list.forEach(course => {
            container.innerHTML += `
                <div class="course-card">
                    <h3>${course.title}</h3>
                    <p>${course.description}</p>
                    <button onclick="enroll(${course.id})">Enroll</button>
                </div>
            `;
        });

    } catch (error) {
        console.log("Error loading courses:", error);
    }
}

loadCourses();

// ================= LOGIN =================
async function loginUser() {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    try {
        let res = await fetch(BASE_URL + "auth/login/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({email, password})
        });

        let data = await res.json();

        if (res.ok) {
            localStorage.setItem("token", data.access);
            alert("Login successful!");
        } else {
            alert(data.detail || "Invalid login");
        }

    } catch (error) {
        console.log("Login error:", error);
    }
}

// ================= REGISTER =================
async function registerUser() {
    const name = document.getElementById("regName").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;

    try {
        let res = await fetch(BASE_URL + "auth/register/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({name, email, password})
        });

        if (res.ok) {
            alert("Registration successful!");
        } else {
            alert("Registration failed!");
        }

    } catch (error) {
        console.log("Register error:", error);
    }
}

// ================= ENROLL =================
async function enroll(course_id) {
    const token = localStorage.getItem("token");

    if (!token) {
        alert("Please login first!");
        return;
    }

    try {
        let res = await fetch(BASE_URL + "enrollments/enroll/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({course_id})
        });

        if (res.ok) {
            alert("Enrolled successfully!");
        } else {
            alert("Enrollment failed!");
        }

    } catch (error) {
        console.log("Enroll error:", error);
    }
}