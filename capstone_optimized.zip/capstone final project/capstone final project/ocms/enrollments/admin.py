from django.contrib import admin
from .models import Enrollment, LectureProgress

admin.site.register(Enrollment)
admin.site.register(LectureProgress)