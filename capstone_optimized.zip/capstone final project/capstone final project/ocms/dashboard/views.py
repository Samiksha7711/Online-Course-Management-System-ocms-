from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from enrollments.models import Enrollment

@login_required
def dashboard_view(request):
    enrollments = Enrollment.objects.filter(student=request.user)
    return render(request, 'dashboard.html', {
        'enrollments': enrollments
    })
    
def home(request):
    return render(request, 'login.html')